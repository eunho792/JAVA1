
public interface Plane2D {

		int getArea();
		
}
